package com.cg.products;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsProjectApplicationTests {

	
	void contextLoads() {
	}

}
